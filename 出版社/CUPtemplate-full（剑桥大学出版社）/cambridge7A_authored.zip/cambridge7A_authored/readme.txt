% readme.txt for the cambridge7A design for authored books
% 2011/02/28, v3.00 gamma

The 30 files included in this distribution are:

01authored.tex
02authored.tex
03authored.tex
04authored.tex
05authored.tex
06authored.tex
07authored.tex
amsthdoc.pdf
amsthm.sty
appnum.tex
authored_guide.bbl
authored_guide.gls
authored_guide.pdf
authored_guide.tex
authored_preface.tex
authors.ind
cambridge7A.cls
cambridgeauthordate.bst
cantor1.eps
floatpag.sty
glossary.sty
multind.sty
natbib.dtx
natbib.sty
percolation.bib
readme.txt
root.tex
rotating.sty
subject.ind
theorem.tex

To run the guide through LaTeX, you need to run something like this (depending on your installation):
  latex cambridge7Aguide

Run this three times, then make a ps or pdf using the driver you have, e.g. dvips

If you are missing any other standard files, go to http://www.ctan.org/ to download them



