% readme.txt for the cambridge7A design
% 2010/09/09, v2.10

The 25 files included in this distribution are:

amsthdoc.pdf
amsthm.sty
appendixA.tex
appendixB.tex
appendixC.tex
authors.ind
cambridge7A.cls
cambridge7Aguide.bbl
cambridge7Aguide.pdf
cambridge7Aguide.tex
cambridgeauthordate.bst
cantor1.eps
chap1.tex
chap2.tex
chap3.tex
chap4.tex
chap5.tex
floatpag.sty
multind.sty
natbib.dtx
natbib.sty
percolation.bib
readme.txt
rotating.sty
subject.ind

To run the guide through LaTeX, you need to run something like this (depending on your installation):
  latex cambridge7Aguide

Run this three times, then make a ps or pdf using the driver you have, e.g. dvips

If you are missing any other standard files, go to http://www.ctan.org/ to download them



