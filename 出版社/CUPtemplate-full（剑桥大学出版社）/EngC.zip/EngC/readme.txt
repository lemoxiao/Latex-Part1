% readme.txt for the EngC design
% 2011/02/03, v1.10

The 29 files included in this distribution are:

amsthdoc.pdf
amsthm.sty
appendixA.tex
appendixB.tex
appendixC.tex
authors.ind
cantor1.eps
chap1.tex
chap2.tex
chap3.tex
chap4.tex
chap5.tex
EngC.cls
EngCguide.bbl
EngCguide.pdf
EngCguide.tex
floatpag.sty
framed.sty
harvard.sty
helvneue.sty
multind.sty
nfssext.sty
notation.tex
percolation.bib
readme.txt
rotating.sty
sidecap.sty
soul.sty
subject.ind

To run the guide through LaTeX, you need to run something like this (depending on your installation):
  latex EngCguide

Run this three times, then make a ps or pdf using the driver you have, e.g. dvips

If you are missing any standard files, go to the Comprehensive TeX Archive Network at:
  http://www.ctan.org/



