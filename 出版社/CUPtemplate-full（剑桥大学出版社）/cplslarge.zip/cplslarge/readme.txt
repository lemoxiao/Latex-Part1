cplslarge
------------------------------------------

The following files are available in cplslarge.zip archive:

cplslarge.cls	   - This is the LaTeX2e class file for cplslarge template
cambridgeauthordate.bst - This is the BibTeX style file for cplslarge template
cplslargesample.bib   	   - This is the Source file for cplslarge BibTeX template
cplslargeguide.pdf    	   - This is PDF of Author Guide for cplslarge template
sample.pdf            	   - This is PDF file of sample LaTeX document for cplslarge template
sample.tex            	   - LaTeX document of driver sample
sample.pic                  	   - LaTeX document of photogallery
sample.ttl               	   - LaTeX document of frontmatter sample
cplsfigure.eps        	   - Graphics file used in sample
camlogo.eps	   - Graphics file used in sample
acknow.tex	   - LaTeX document of acknowledgments
appendix.tex	   - LaTeX document of appendix
chap1.tex		   - LaTeX document of chapter 1
chap2.tex		   - LaTeX document of chapter 2
editedloc.tex	   - LaTeX document of edited list of contributer
foreward.tex	   - LaTeX document of foreward 

Happy TeXing!!!

Aptara