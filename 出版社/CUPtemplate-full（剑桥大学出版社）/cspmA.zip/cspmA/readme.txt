% readme.txt for the cspmA design
% 2009/09/17, v2.00

The 25 files included in this distribution are:

amsthdoc.pdf
amsthm.sty
appendixA.tex
appendixB.tex
appendixC.tex
authors.ind
cambridgeauthordate.bst
cantor1.eps
chap1.tex
chap2.tex
chap3.tex
chap4.tex
chap5.tex
cspmA.cls
cspmAguide.bbl
cspmAguide.pdf
cspmAguide.tex
floatpag.sty
multind.sty
natbib.dtx
natbib.sty
percolation.bib
readme.txt
rotating.sty
subject.ind

To run the guide through LaTeX, you need to run something like this (depending on your installation):
  latex cspmAguide

Run this three times, then make a ps or pdf using the driver you have, e.g. dvips

If you are missing any other standard files, go to http://www.ctan.org/ to download them



