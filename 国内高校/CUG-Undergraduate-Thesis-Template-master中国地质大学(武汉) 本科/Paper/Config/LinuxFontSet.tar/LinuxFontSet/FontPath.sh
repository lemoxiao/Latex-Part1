#!/bin/bash

#Onion
#2012.12.22

FontPath_1='/usr/local/texlive/texmf-dist/tex/latex/ctex/fontset/'
FontPath_2='/usr/local/texlive/2012/texmf-dist/tex/latex/ctex/fontset/'
FontPath_3='/usr/share/texlive/texmf-dist/tex/latex/ctex/fontset/'

if [ -d $FontPath_1 ]; then
   sudo  cp -pRv  *   $FontPath_1
   echo  "Copyed To $FontPath_1"
	elif  [ -d $FontPath_2 ];then
	sudo cp -pRv  *  $FontPath_2
	echo "Copyed To $FontPath_2"
		elif  [ -d $FontPath_3 ];then
		sudo cp -pRv  *  $FontPath_3
		echo "Copyed To $FontPath_3"
     else
	echo "Nothing did,because no directdory found"		
fi
read -p "Press any key to continue" var 
