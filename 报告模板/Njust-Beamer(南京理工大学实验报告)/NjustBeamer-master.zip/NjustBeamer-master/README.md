# NjustBeamer

This is a beamer in LaTeX for NUST.

非官方版南京理工大学Beamer模板，适合做学术报告。

使用方法：

使用TeX发行版本：TeXlive，使用TeXstudio+XeLatex命令编译；

运行NJUSTmain文件，可以先行查看PDF来确认是否符合自己对Beamer的要求。
