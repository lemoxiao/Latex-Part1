# NjustLabReport

This is a laboratory report(LabReport) for almost all students in NUST.

非官方版南理工实验报告模板，比较干净清爽，喜欢的同学可以拿去下载。

使用方法：

使用TeX发行版本：TeXlive，使用TeXstudio+XeLaTeX命令编译；

运行NJUSTmain文件。
